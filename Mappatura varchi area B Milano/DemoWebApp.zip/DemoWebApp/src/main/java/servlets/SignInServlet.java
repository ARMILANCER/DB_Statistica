package servlets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/SignInServlet")
public class SignInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignInServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String user;
		user = email + ";" +password;
		File users = new File("users.csv");
		String csvSplitBy = ";";
		String line ="";
		boolean isFind= false;
		 try (BufferedReader br = new BufferedReader(new FileReader(users))) {
	            while ((line = br.readLine()) != null && !isFind) {
	                String[] data = line.split(csvSplitBy);

	                // Stampa i dati letti
	                System.out.println("Email: " + data[0] + ", Password: " + data[1]);
	                if(data[0].equalsIgnoreCase(email)&&data[1].equals(password)) {
	                	isFind = true;
	                }
	            }
	            if(isFind) {
	            	response.getWriter().print("Benvenuto!");
	            	
	            	
	            	HttpSession session = request.getSession();
	            	
	            	session.setAttribute("email", email);
	            	session.setAttribute("isLogged", true);
	            }else {
	            	response.getWriter().print("Credenziali errate!");
	            }
	            
	        } catch (IOException e) {
	            System.out.println("An error occurred.");
	            e.printStackTrace();
	        }
	}

}
